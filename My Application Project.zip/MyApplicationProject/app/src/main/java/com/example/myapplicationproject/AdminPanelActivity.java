package com.example.myapplicationproject;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import java.util.List;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class AdminPanelActivity extends AppCompatActivity {

    // ── Tab state
    static final int TAB_EVENTS       = 0;
    static final int TAB_REGISTRATIONS = 1;
    int currentTab = TAB_EVENTS;

    // ── Events tab
    ListView listViewEvents;
    Button btnAddEvent;
    ArrayList<Event>  eventDataList  = new ArrayList<>();
    ArrayList<String> eventDisplayList = new ArrayList<>();
    ArrayAdapter<String> eventAdapter;
    DatabaseReference eventsRef;

    // ── Registrations tab
    ListView listViewAdmin;
    TextView tvAdminTitle;
    EditText etSearch;
    TextView tvTotalAll, tvTotalLabel;
    LinearLayout registrationsTab, eventsTab;
    Button btnTabEvents, btnTabRegs;

    DatabaseReference regsRef;
    ArrayList<Map<String, String>> fullDataList  = new ArrayList<>();
    ArrayList<String> displayList  = new ArrayList<>();
    ArrayList<String> keyList      = new ArrayList<>();
    ArrayAdapter<String> regsAdapter;
    String currentEventType = "";
    List<Event> allEvents = new ArrayList<>();

    // Counts
    Map<String, Integer> countMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_panel);

        eventsRef = FirebaseDatabase.getInstance(
                "https://collegeevents-75722-default-rtdb.firebaseio.com/")
                .getReference("events");
        regsRef = FirebaseDatabase.getInstance(
                "https://collegeevents-75722-default-rtdb.firebaseio.com/")
                .getReference("registrations");

        // Tabs
        btnTabEvents = findViewById(R.id.btnTabEvents);
        btnTabRegs   = findViewById(R.id.btnTabRegs);
        eventsTab    = findViewById(R.id.eventsTab);
        registrationsTab = findViewById(R.id.registrationsTab);

        btnTabEvents.setOnClickListener(v -> switchTab(TAB_EVENTS));
        btnTabRegs.setOnClickListener(v   -> switchTab(TAB_REGISTRATIONS));

        // Events tab views
        listViewEvents = findViewById(R.id.listViewEvents);
        btnAddEvent    = findViewById(R.id.btnAddEvent);

        eventAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, eventDisplayList);
        listViewEvents.setAdapter(eventAdapter);

        btnAddEvent.setOnClickListener(v -> showAddEventDialog(null));

        listViewEvents.setOnItemClickListener((p, v, pos, id) ->
                showAddEventDialog(eventDataList.get(pos)));

        listViewEvents.setOnItemLongClickListener((p, v, pos, id) -> {
            Event ev = eventDataList.get(pos);
            new AlertDialog.Builder(this)
                    .setTitle("Delete Event")
                    .setMessage("Delete \"" + ev.name + "\"?\nAll registrations for this event will still exist in Firebase.")
                    .setPositiveButton("Delete", (d, w) -> deleteEvent(ev))
                    .setNegativeButton("Cancel", null)
                    .show();
            return true;
        });

        // Registrations tab views
        listViewAdmin = findViewById(R.id.listViewAdmin);
        tvAdminTitle  = findViewById(R.id.tvAdminTitle);
        etSearch      = findViewById(R.id.etSearch);
        tvTotalAll    = findViewById(R.id.tvTotalAll);
        tvTotalLabel  = findViewById(R.id.tvTotalLabel);

        regsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, displayList);
        listViewAdmin.setAdapter(regsAdapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int i, int b, int c) { filterList(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });

        listViewAdmin.setOnItemLongClickListener((p, v, pos, id) -> {
            new AlertDialog.Builder(this)
                    .setTitle("Delete Registration")
                    .setMessage("Delete this entry?")
                    .setPositiveButton("Delete", (d, w) -> deleteRegistration(pos))
                    .setNegativeButton("Cancel", null)
                    .show();
            return true;
        });

        findViewById(R.id.btnShare).setOnClickListener(v -> shareList());

        // Load data
        loadEvents();
        switchTab(TAB_EVENTS);
    }

    // ══════════════════════════════════════════════════════
    // TAB SWITCHING
    // ══════════════════════════════════════════════════════
    private void switchTab(int tab) {
        currentTab = tab;
        if (tab == TAB_EVENTS) {
            eventsTab.setVisibility(View.VISIBLE);
            registrationsTab.setVisibility(View.GONE);
            btnTabEvents.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(0xFFB71C1C));
            btnTabRegs.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(0xFF757575));
        } else {
            eventsTab.setVisibility(View.GONE);
            registrationsTab.setVisibility(View.VISIBLE);
            btnTabRegs.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(0xFFB71C1C));
            btnTabEvents.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(0xFF757575));
            buildEventButtons();
        }
    }

    // ══════════════════════════════════════════════════════
    // EVENTS TAB
    // ══════════════════════════════════════════════════════
    private void loadEvents() {
        eventsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                eventDataList.clear();
                eventDisplayList.clear();
                allEvents.clear();
                countMap.clear();

                for (DataSnapshot child : snapshot.getChildren()) {
                    Event ev = child.getValue(Event.class);
                    if (ev != null) {
                        ev.id = child.getKey();
                        eventDataList.add(ev);
                        allEvents.add(ev);
                        eventDisplayList.add(
                                (ev.emoji != null ? ev.emoji + " " : "") + ev.name
                                + "\n📅 " + ev.dateTime + "  •  📍 " + ev.venue);
                    }
                }
                eventAdapter.notifyDataSetChanged();

                // Load registration counts for each event
                for (Event ev : allEvents) {
                    regsRef.child(ev.type).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot snap) {
                            countMap.put(ev.type, (int) snap.getChildrenCount());
                            updateTotalLabel();
                            if (currentTab == TAB_REGISTRATIONS) buildEventButtons();
                        }
                        @Override public void onCancelled(DatabaseError e) {}
                    });
                }

                if (currentTab == TAB_REGISTRATIONS) buildEventButtons();
            }
            @Override public void onCancelled(DatabaseError error) {
                Toast.makeText(AdminPanelActivity.this, "Error loading events", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateTotalLabel() {
        int total = 0;
        for (int v : countMap.values()) total += v;
        tvTotalAll.setText(String.valueOf(total));
    }

    private void showAddEventDialog(Event existing) {
        boolean isEdit = existing != null;
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_event, null);

        EditText etName  = dialogView.findViewById(R.id.etEventName);
        EditText etType  = dialogView.findViewById(R.id.etEventType);
        EditText etDate  = dialogView.findViewById(R.id.etEventDate);
        EditText etVenue = dialogView.findViewById(R.id.etEventVenue);
        EditText etDesc  = dialogView.findViewById(R.id.etEventDesc);
        EditText etColor = dialogView.findViewById(R.id.etEventColor);
        EditText etEmoji = dialogView.findViewById(R.id.etEventEmoji);

        if (isEdit) {
            etName.setText(existing.name);
            etType.setText(existing.type);
            etDate.setText(existing.dateTime);
            etVenue.setText(existing.venue);
            etDesc.setText(existing.description);
            etColor.setText(existing.color);
            etEmoji.setText(existing.emoji);
        }

        new AlertDialog.Builder(this)
                .setTitle(isEdit ? "✏️ Edit Event" : "➕ Add New Event")
                .setView(dialogView)
                .setPositiveButton(isEdit ? "Update" : "Add", (d, w) -> {
                    String name  = etName.getText().toString().trim();
                    String type  = etType.getText().toString().trim();
                    String date  = etDate.getText().toString().trim();
                    String venue = etVenue.getText().toString().trim();
                    String desc  = etDesc.getText().toString().trim();
                    String color = etColor.getText().toString().trim();
                    String emoji = etEmoji.getText().toString().trim();

                    if (name.isEmpty() || type.isEmpty() || date.isEmpty() || venue.isEmpty()) {
                        Toast.makeText(this, "Name, Type, Date and Venue are required!", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (color.isEmpty()) color = "#1565C0";
                    if (emoji.isEmpty()) emoji = "📌";

                    Event ev = new Event(name, type, date, venue, desc, color, emoji);
                    if (isEdit) {
                        eventsRef.child(existing.id).setValue(ev)
                                .addOnSuccessListener(u -> Toast.makeText(this, "Event updated!", Toast.LENGTH_SHORT).show())
                                .addOnFailureListener(e -> Toast.makeText(this, "Update failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                    } else {
                        eventsRef.push().setValue(ev)
                                .addOnSuccessListener(u -> Toast.makeText(this, "Event added!", Toast.LENGTH_SHORT).show())
                                .addOnFailureListener(e -> Toast.makeText(this, "Add failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteEvent(Event ev) {
        eventsRef.child(ev.id).removeValue()
                .addOnSuccessListener(u -> Toast.makeText(this, "Event deleted!", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show());
    }

    // ══════════════════════════════════════════════════════
    // REGISTRATIONS TAB
    // ══════════════════════════════════════════════════════
    private void buildEventButtons() {
        LinearLayout container = findViewById(R.id.eventButtonsContainer);
        container.removeAllViews();

        for (Event ev : allEvents) {
            int count = countMap.getOrDefault(ev.type, 0);
            Button btn = new Button(this);
            btn.setText(ev.emoji + " " + ev.name + " (" + count + ")");
            btn.setTextColor(0xFFFFFFFF);
            btn.setTextSize(11f);
            try {
                btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                        android.graphics.Color.parseColor(ev.color)));
            } catch (Exception e) {
                btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF1565C0));
            }
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            p.setMargins(16, 6, 16, 6);
            btn.setLayoutParams(p);
            btn.setOnClickListener(v -> loadRegistrations(ev.type, ev.name));
            container.addView(btn);
        }

        // Share button at bottom
        Button btnShare = new Button(this);
        btnShare.setText("📤 Share List");
        btnShare.setTextColor(0xFFFFFFFF);
        btnShare.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF37474F));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        sp.setMargins(16, 6, 16, 6);
        btnShare.setLayoutParams(sp);
        btnShare.setOnClickListener(v -> shareList());
        container.addView(btnShare);
    }

    private void loadRegistrations(String eventType, String eventName) {
        currentEventType = eventType;
        etSearch.setText("");
        tvAdminTitle.setText("📋 " + eventName);
        fullDataList.clear();
        displayList.clear();
        keyList.clear();

        regsRef.child(eventType).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                fullDataList.clear();
                displayList.clear();
                keyList.clear();
                SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault());

                for (DataSnapshot child : snapshot.getChildren()) {
                    Map<String, String> data = (Map<String, String>) child.getValue();
                    if (data != null) {
                        String timeStr = "";
                        try {
                            long ts = Long.parseLong(data.get("timestamp"));
                            timeStr = sdf.format(new Date(ts));
                        } catch (Exception ignored) {}

                        fullDataList.add(data);
                        keyList.add(child.getKey());
                        displayList.add(
                                "👤 " + data.get("name") + " | " + data.get("branch")
                                + "\n📅 Year: " + data.get("year") + " | 📞 " + data.get("phone")
                                + "\n🆔 " + data.get("registrationId") + "\n🕐 " + timeStr);
                    }
                }
                if (displayList.isEmpty()) displayList.add("No registrations yet.");
                regsAdapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(AdminPanelActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void filterList(String query) {
        displayList.clear();
        keyList.clear();
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault());
        String q = query.toLowerCase().trim();

        regsRef.child(currentEventType).get().addOnSuccessListener(snapshot -> {
            List<String> allKeys = new ArrayList<>();
            for (DataSnapshot child : snapshot.getChildren()) allKeys.add(child.getKey());

            for (int i = 0; i < fullDataList.size(); i++) {
                Map<String, String> data = fullDataList.get(i);
                String name   = data.getOrDefault("name", "").toLowerCase();
                String phone  = data.getOrDefault("phone", "").toLowerCase();
                String branch = data.getOrDefault("branch", "").toLowerCase();

                if (q.isEmpty() || name.contains(q) || phone.contains(q) || branch.contains(q)) {
                    String timeStr = "";
                    try {
                        long ts = Long.parseLong(data.get("timestamp"));
                        timeStr = sdf.format(new Date(ts));
                    } catch (Exception ignored) {}

                    displayList.add("👤 " + data.get("name") + " | " + data.get("branch")
                            + "\n📅 Year: " + data.get("year") + " | 📞 " + data.get("phone")
                            + "\n🆔 " + data.get("registrationId") + "\n🕐 " + timeStr);
                    if (i < allKeys.size()) keyList.add(allKeys.get(i));
                }
            }
            if (displayList.isEmpty() && !q.isEmpty())
                displayList.add("No results for \"" + query + "\"");
            regsAdapter.notifyDataSetChanged();
        });
    }

    private void shareList() {
        if (currentEventType.isEmpty()) {
            Toast.makeText(this, "Select an event first!", Toast.LENGTH_SHORT).show(); return;
        }
        if (fullDataList.isEmpty()) {
            Toast.makeText(this, "No registrations to share!", Toast.LENGTH_SHORT).show(); return;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault());
        StringBuilder sb = new StringBuilder("📋 *" + currentEventType + " Registrations*\nTotal: " + fullDataList.size() + "\n\n");
        int i = 1;
        for (Map<String, String> data : fullDataList) {
            String timeStr = "";
            try { long ts = Long.parseLong(data.get("timestamp")); timeStr = sdf.format(new Date(ts)); } catch (Exception ignored) {}
            sb.append(i++).append(". ").append(data.get("name"))
              .append("\n   Branch: ").append(data.get("branch")).append(" | Year: ").append(data.get("year"))
              .append("\n   Phone: ").append(data.get("phone")).append("\n   ID: ").append(data.get("registrationId"))
              .append("\n   Registered: ").append(timeStr).append("\n\n");
        }
        android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(android.content.Intent.EXTRA_TEXT, sb.toString());
        startActivity(android.content.Intent.createChooser(intent, "Share via"));
    }

    private void deleteRegistration(int position) {
        if (keyList.isEmpty() || position >= keyList.size()) return;
        String key = keyList.get(position);
        if (key == null || key.isEmpty()) {
            Toast.makeText(this, "Clear search before deleting.", Toast.LENGTH_SHORT).show(); return;
        }
        regsRef.child(currentEventType).child(key).removeValue()
                .addOnSuccessListener(v -> Toast.makeText(this, "Deleted!", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show());
    }
}
