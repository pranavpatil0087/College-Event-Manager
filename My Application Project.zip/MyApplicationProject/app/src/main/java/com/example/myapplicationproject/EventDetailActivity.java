package com.example.myapplicationproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class EventDetailActivity extends AppCompatActivity {

    TextView tvEventName, tvDateTime, tvVenue, tvDesc;
    Button btnRegisterEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);

        tvEventName = findViewById(R.id.tvEventName);
        tvDateTime = findViewById(R.id.tvDateTime);
        tvVenue = findViewById(R.id.tvVenue);
        tvDesc = findViewById(R.id.tvDesc);
        btnRegisterEvent = findViewById(R.id.btnRegisterEvent);

        // Get data from Dashboard
        String eventType = getIntent().getStringExtra("eventType");
        String eventName = getIntent().getStringExtra("eventName");
        String dateTime = getIntent().getStringExtra("eventDateTime");
        String venue = getIntent().getStringExtra("eventVenue");
        String desc = getIntent().getStringExtra("eventDesc");

        tvEventName.setText(eventName);
        tvDateTime.setText(dateTime);
        tvVenue.setText(venue);
        tvDesc.setText(desc);

        btnRegisterEvent.setOnClickListener(v -> {
            Intent intent = new Intent(this, RegistrationFormActivity.class);
            intent.putExtra("eventType", eventType);
            intent.putExtra("eventName", eventName);
            intent.putExtra("eventDateTime", dateTime);
            intent.putExtra("eventVenue", venue);
            startActivity(intent);
        });
    }
}