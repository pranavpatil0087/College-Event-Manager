package com.example.myapplicationproject;

public class Event {
    public String id;
    public String name;
    public String type;
    public String dateTime;
    public String venue;
    public String description;
    public String color;
    public String emoji;
    public long createdAt;

    public Event() {} // Required for Firebase

    public Event(String name, String type, String dateTime,
                 String venue, String description, String color, String emoji) {
        this.name        = name;
        this.type        = type;
        this.dateTime    = dateTime;
        this.venue       = venue;
        this.description = description;
        this.color       = color;
        this.emoji       = emoji;
        this.createdAt   = System.currentTimeMillis();
    }
}
