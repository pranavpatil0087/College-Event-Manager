package com.example.myapplicationproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

public class ConfirmationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        String regId = getIntent().getStringExtra("registrationId");
        String name = getIntent().getStringExtra("name");
        String eventName = getIntent().getStringExtra("eventName");
        String dateTime = getIntent().getStringExtra("eventDateTime");
        String venue = getIntent().getStringExtra("eventVenue");

        ((TextView) findViewById(R.id.tvRegId)).setText("Registration ID: " + regId);
        ((TextView) findViewById(R.id.tvConfirmName)).setText("Name: " + name);
        ((TextView) findViewById(R.id.tvConfirmEvent)).setText("Event: " + eventName);
        ((TextView) findViewById(R.id.tvConfirmDate)).setText("Date: " + dateTime);
        ((TextView) findViewById(R.id.tvConfirmVenue)).setText("Venue: " + venue);

        Button btnBack = findViewById(R.id.btnBackDashboard);
        btnBack.setOnClickListener(v -> goToDashboard());

        // FIX 5: Hardware back button goes to Dashboard, not back to the form
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                goToDashboard();
            }
        });
    }

    private void goToDashboard() {
        Intent intent = new Intent(this, DashboardActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}