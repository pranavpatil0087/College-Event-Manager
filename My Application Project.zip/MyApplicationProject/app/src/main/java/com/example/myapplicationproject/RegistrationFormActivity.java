package com.example.myapplicationproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;

public class RegistrationFormActivity extends AppCompatActivity {

    EditText etName, etPhone;
    Spinner spinnerBranch, spinnerYear;
    Button btnSubmit;
    DatabaseReference databaseRef;

    final String[] branches = {
            "IT - Information Technology",
            "AI ML - Artificial Intelligence & ML",
            "CE - Computer Engineering",
            "CS - Computer Science"
    };

    final String[] years = {
            "1st Year", "2nd Year", "3rd Year", "4th Year"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_form);

        // FIX 1: Provide the Firebase Realtime Database URL explicitly
        databaseRef = FirebaseDatabase.getInstance(
                        "https://collegeevents-75722-default-rtdb.firebaseio.com/")
                .getReference("registrations");

        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        spinnerBranch = findViewById(R.id.spinnerBranch);
        spinnerYear = findViewById(R.id.spinnerYear);
        btnSubmit = findViewById(R.id.btnSubmit);

        ArrayAdapter<String> branchAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, branches);
        spinnerBranch.setAdapter(branchAdapter);

        ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, years);
        spinnerYear.setAdapter(yearAdapter);

        String eventType     = getIntent().getStringExtra("eventType");
        String eventName     = getIntent().getStringExtra("eventName");
        String eventDateTime = getIntent().getStringExtra("eventDateTime");
        String eventVenue    = getIntent().getStringExtra("eventVenue");

        // FIX 6: Guard against null eventType
        if (eventType == null || eventType.isEmpty()) {
            Toast.makeText(this, "Event data missing. Please go back and try again.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        btnSubmit.setOnClickListener(v ->
                submitRegistration(eventType, eventName, eventDateTime, eventVenue));
    }

    private void submitRegistration(String eventType, String eventName,
                                    String eventDateTime, String eventVenue) {

        String name   = etName.getText().toString().trim();
        String phone  = etPhone.getText().toString().trim();
        String branch = spinnerBranch.getSelectedItem().toString();
        String year   = spinnerYear.getSelectedItem().toString();

        if (name.isEmpty()) {
            Toast.makeText(this, "Enter name!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (phone.length() != 10) {
            Toast.makeText(this, "Enter valid 10-digit phone number!", Toast.LENGTH_SHORT).show();
            return;
        }

        btnSubmit.setEnabled(false);
        btnSubmit.setText("Submitting...");

        // FIX 2: Null-safe regId generation
        DatabaseReference pushRef = databaseRef.child(eventType).push();
        String regId = pushRef.getKey();
        if (regId == null) {
            regId = "reg_" + System.currentTimeMillis();
        }
        String regIdShort = "EVT" + System.currentTimeMillis() % 100000;

        Map<String, String> data = new HashMap<>();
        data.put("registrationId", regIdShort);
        data.put("name", name);
        data.put("branch", branch);
        data.put("year", year);
        data.put("phone", phone);
        data.put("eventType", eventType);
        data.put("eventName", eventName);
        data.put("eventDateTime", eventDateTime);
        data.put("eventVenue", eventVenue);
        data.put("timestamp", String.valueOf(System.currentTimeMillis()));

        final String finalRegIdShort = regIdShort;
        pushRef.setValue(data)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "Registered Successfully!", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(this, ConfirmationActivity.class);
                    intent.putExtra("registrationId", finalRegIdShort);
                    intent.putExtra("name", name);
                    intent.putExtra("eventName", eventName);
                    intent.putExtra("eventDateTime", eventDateTime);
                    intent.putExtra("eventVenue", eventVenue);

                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    btnSubmit.setEnabled(true);
                    btnSubmit.setText("SUBMIT REGISTRATION");
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }
}