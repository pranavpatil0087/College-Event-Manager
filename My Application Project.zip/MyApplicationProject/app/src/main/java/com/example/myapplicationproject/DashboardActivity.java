package com.example.myapplicationproject;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.google.firebase.database.*;
import java.util.ArrayList;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    LinearLayout eventsContainer;
    ProgressBar progressBar;
    TextView tvNoEvents;
    DatabaseReference eventsRef;
    List<Event> eventList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        eventsContainer = findViewById(R.id.eventsContainer);
        progressBar     = findViewById(R.id.progressBar);
        tvNoEvents      = findViewById(R.id.tvNoEvents);

        eventsRef = FirebaseDatabase.getInstance(
                "https://collegeevents-75722-default-rtdb.firebaseio.com/")
                .getReference("events");

        loadEvents();
    }

    private void loadEvents() {
        progressBar.setVisibility(View.VISIBLE);
        tvNoEvents.setVisibility(View.GONE);

        eventsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                eventList.clear();
                eventsContainer.removeAllViews();
                progressBar.setVisibility(View.GONE);

                for (DataSnapshot child : snapshot.getChildren()) {
                    Event event = child.getValue(Event.class);
                    if (event != null) {
                        event.id = child.getKey();
                        eventList.add(event);
                        addEventCard(event);
                    }
                }

                if (eventList.isEmpty()) {
                    tvNoEvents.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(DashboardActivity.this,
                        "Failed to load events: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addEventCard(Event event) {
        // Parse color safely
        int bgColor;
        try {
            bgColor = Color.parseColor(event.color);
        } catch (Exception e) {
            bgColor = Color.parseColor("#1565C0");
        }

        // Card
        CardView card = new CardView(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, 36);
        card.setLayoutParams(cardParams);
        card.setCardElevation(12f);
        card.setRadius(24f);

        // Inner layout
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(48, 40, 48, 40);
        inner.setBackgroundColor(bgColor);

        // Title: emoji + name
        TextView tvName = new TextView(this);
        tvName.setText((event.emoji != null ? event.emoji + " " : "") + event.name);
        tvName.setTextSize(18f);
        tvName.setTextColor(Color.WHITE);
        tvName.setTypeface(null, android.graphics.Typeface.BOLD);

        // Subtitle: date
        TextView tvDate = new TextView(this);
        tvDate.setText("📅 " + event.dateTime + "  •  📍 " + event.venue);
        tvDate.setTextColor(Color.argb(200, 255, 255, 255));
        tvDate.setTextSize(13f);
        LinearLayout.LayoutParams dateParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        dateParams.setMargins(0, 8, 0, 0);
        tvDate.setLayoutParams(dateParams);

        inner.addView(tvName);
        inner.addView(tvDate);
        card.addView(inner);

        card.setOnClickListener(v -> {
            Intent intent = new Intent(this, EventDetailActivity.class);
            intent.putExtra("eventId",       event.id);
            intent.putExtra("eventType",     event.type);
            intent.putExtra("eventName",     event.name);
            intent.putExtra("eventDateTime", event.dateTime);
            intent.putExtra("eventVenue",    event.venue);
            intent.putExtra("eventDesc",     event.description);
            startActivity(intent);
        });

        eventsContainer.addView(card);
    }
}
