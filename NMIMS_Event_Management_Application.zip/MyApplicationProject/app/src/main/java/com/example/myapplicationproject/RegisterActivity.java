package com.example.myapplicationproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {

    EditText etRegEmail, etRegPassword;
    Button btnRegister, btnBackLogin;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mAuth         = FirebaseAuth.getInstance();
        etRegEmail    = findViewById(R.id.etRegEmail);
        etRegPassword = findViewById(R.id.etRegPassword);
        btnRegister   = findViewById(R.id.btnRegister);
        btnBackLogin  = findViewById(R.id.btnBackLogin);
        btnRegister.setOnClickListener(v -> registerUser());
        btnBackLogin.setOnClickListener(v -> finish());
    }

    private void registerUser() {
        String email = etRegEmail.getText().toString().trim();
        String pass  = etRegPassword.getText().toString().trim();
        if (email.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show(); return;
        }
        if (pass.length() < 6) {
            Toast.makeText(this, "Password min 6 characters", Toast.LENGTH_SHORT).show(); return;
        }
        mAuth.createUserWithEmailAndPassword(email, pass)
                .addOnSuccessListener(a -> {
                    Toast.makeText(this, "Registered!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(this, DashboardActivity.class));
                    finish();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Error: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show());
    }
}