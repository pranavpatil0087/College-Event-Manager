package com.example.myapplicationproject;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.google.firebase.database.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class DashboardActivity extends AppCompatActivity {

    View eventsTab, registrationsTab;
    Button btnTabEvents, btnTabRegistrations, btnCalendar, btnShareExcel;
    LinearLayout eventsContainer, eventFilterContainer;
    EditText etSearchEvents, etSearch;
    ListView listRegistrations;
    TextView tvTotalCount;

    DatabaseReference databaseRef;
    List<String> allRegistrations = new ArrayList<>();
    List<String> filteredList     = new ArrayList<>();
    ArrayAdapter<String> adapter;
    String currentFilter = "";

    String[][] events = {
            {"Seminar",   "🎤 Career Guidance Seminar",    "2025-05-15", "Seminar Hall A",  "Expert talk on career paths, placement tips and industry insights.", "#C62828"},
            {"Workshop",  "🛠️ Android Dev Workshop",        "2025-05-20", "Computer Lab 2", "Hands-on Android development workshop with Firebase integration.",   "#B71C1C"},
            {"Tech Fest", "🚀 Annual Tech Festival",        "2025-06-01", "Main Auditorium","Project exhibition, competitions and technical hackathon.",           "#8B0000"},
            {"Hackathon", "💻 24-Hour Hackathon",           "2025-06-10", "Innovation Lab", "Build innovative solutions in 24 hours. Open to all branches.",      "#D32F2F"},
            {"Cultural",  "🎭 Annual Cultural Fest",        "2025-06-20", "College Ground", "Music, dance, drama and fun activities for all students.",           "#E53935"}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        databaseRef          = FirebaseDatabase.getInstance().getReference("registrations");
        eventsTab            = findViewById(R.id.eventsTab);
        registrationsTab     = findViewById(R.id.registrationsTab);
        btnTabEvents         = findViewById(R.id.btnTabEvents);
        btnTabRegistrations  = findViewById(R.id.btnTabRegistrations);
        btnCalendar          = findViewById(R.id.btnCalendar);
        btnShareExcel        = findViewById(R.id.btnShareExcel);
        eventsContainer      = findViewById(R.id.eventsContainer);
        eventFilterContainer = findViewById(R.id.eventFilterContainer);
        etSearchEvents       = findViewById(R.id.etSearchEvents);
        etSearch             = findViewById(R.id.etSearch);
        listRegistrations    = findViewById(R.id.listRegistrations);
        tvTotalCount         = findViewById(R.id.tvTotalCount);

        adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, filteredList);
        listRegistrations.setAdapter(adapter);

        buildEventCards(null);
        buildFilterButtons();
        loadAllRegistrations();

        btnTabEvents.setOnClickListener(v -> showEventsTab());
        btnTabRegistrations.setOnClickListener(v -> showRegistrationsTab());
        btnCalendar.setOnClickListener(v ->
                startActivity(new Intent(this, CalendarActivity.class)));
        btnShareExcel.setOnClickListener(v -> shareAsExcel());

        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int a,int b,int c){}
            public void onTextChanged(CharSequence s,int a,int b,int c){ filterList(s.toString()); }
            public void afterTextChanged(Editable s){}
        });
        etSearchEvents.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int a,int b,int c){}
            public void onTextChanged(CharSequence s,int a,int b,int c){ buildEventCards(s.toString()); }
            public void afterTextChanged(Editable s){}
        });
    }

    private void buildEventCards(String query) {
        eventsContainer.removeAllViews();
        for (String[] event : events) {
            if (query != null && !query.isEmpty() &&
                    !event[1].toLowerCase().contains(query.toLowerCase())) continue;

            // Outer card
            CardView card = new CardView(this);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            cp.setMargins(0, 0, 0, 16);
            card.setLayoutParams(cp);
            card.setRadius(20f);
            card.setCardElevation(8f);
            card.setUseCompatPadding(true);

            // Inner layout
            LinearLayout inner = new LinearLayout(this);
            inner.setOrientation(LinearLayout.VERTICAL);
            inner.setPadding(0, 0, 0, 0);

            // Top color band
            LinearLayout topBand = new LinearLayout(this);
            topBand.setOrientation(LinearLayout.HORIZONTAL);
            topBand.setPadding(24, 20, 24, 20);
            try { topBand.setBackgroundColor(Color.parseColor(event[5])); }
            catch (Exception e) { topBand.setBackgroundColor(0xFFC62828); }
            topBand.setGravity(android.view.Gravity.CENTER_VERTICAL);

            LinearLayout textCol = new LinearLayout(this);
            textCol.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams tcLp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
            textCol.setLayoutParams(tcLp);

            TextView tvName = new TextView(this);
            tvName.setText(event[1]);
            tvName.setTextSize(17);
            tvName.setTextColor(Color.WHITE);
            tvName.setTypeface(null, android.graphics.Typeface.BOLD);

            TextView tvMeta = new TextView(this);
            tvMeta.setText("📅 " + event[2] + "   📍 " + event[3]);
            tvMeta.setTextColor(0xFFFFCDD2);
            tvMeta.setTextSize(12);
            tvMeta.setPadding(0, 4, 0, 0);

            textCol.addView(tvName);
            textCol.addView(tvMeta);

            // Count badge
            TextView tvBadge = new TextView(this);
            tvBadge.setText("👥 --");
            tvBadge.setTextColor(Color.WHITE);
            tvBadge.setTextSize(11);
            tvBadge.setBackgroundColor(0x33000000);
            tvBadge.setPadding(16, 8, 16, 8);

            databaseRef.child(event[0]).addValueEventListener(new ValueEventListener() {
                @Override public void onDataChange(DataSnapshot s) {
                    tvBadge.setText("👥 " + s.getChildrenCount());
                }
                @Override public void onCancelled(DatabaseError e) {}
            });

            topBand.addView(textCol);
            topBand.addView(tvBadge);

            // Bottom white strip
            LinearLayout bottomStrip = new LinearLayout(this);
            bottomStrip.setBackgroundColor(Color.WHITE);
            bottomStrip.setPadding(24, 12, 24, 14);
            bottomStrip.setOrientation(LinearLayout.HORIZONTAL);
            bottomStrip.setGravity(android.view.Gravity.CENTER_VERTICAL);

            TextView tvDesc = new TextView(this);
            tvDesc.setText(event[4]);
            tvDesc.setTextSize(12);
            tvDesc.setTextColor(0xFF888888);
            LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
            tvDesc.setLayoutParams(descLp);
            tvDesc.setMaxLines(1);
            tvDesc.setEllipsize(android.text.TextUtils.TruncateAt.END);

            TextView tvArrow = new TextView(this);
            tvArrow.setText("→");
            tvArrow.setTextSize(18);
            tvArrow.setTextColor(0xFFC62828);
            tvArrow.setTypeface(null, android.graphics.Typeface.BOLD);

            bottomStrip.addView(tvDesc);
            bottomStrip.addView(tvArrow);

            inner.addView(topBand);
            inner.addView(bottomStrip);
            card.addView(inner);

            final String[] e = event;
            card.setOnClickListener(v -> checkVenueAndOpen(e));
            eventsContainer.addView(card);
        }
    }

    private void checkVenueAndOpen(String[] event) {
        databaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                boolean conflict = false;
                for (DataSnapshot eventSnap : snapshot.getChildren()) {
                    if (eventSnap.getKey() != null &&
                            eventSnap.getKey().equals(event[0])) continue;
                    for (DataSnapshot reg : eventSnap.getChildren()) {
                        String v = reg.child("eventVenue").getValue(String.class);
                        String d = reg.child("eventDateTime").getValue(String.class);
                        if (v != null && d != null &&
                                v.equals(event[3]) && d.contains(event[2])) {
                            conflict = true; break;
                        }
                    }
                    if (conflict) break;
                }
                Intent intent = new Intent(DashboardActivity.this, EventDetailActivity.class);
                intent.putExtra("eventType",     event[0]);
                intent.putExtra("eventName",     event[1]);
                intent.putExtra("eventDateTime", event[2] + ", 10:00 AM");
                intent.putExtra("eventVenue",    event[3]);
                intent.putExtra("eventDesc",     event[4]);
                intent.putExtra("venueConflict", conflict);
                startActivity(intent);
            }
            @Override public void onCancelled(DatabaseError e) {}
        });
    }

    private void buildFilterButtons() {
        eventFilterContainer.removeAllViews();
        String[] labels = {"ALL","Seminar","Workshop","Tech Fest","Hackathon","Cultural"};
        int[] colors    = {0xFF1A237E,0xFFC62828,0xFFB71C1C,0xFF8B0000,0xFFD32F2F,0xFFE53935};
        for (int i = 0; i < labels.length; i++) {
            Button btn = new Button(this);
            btn.setText(labels[i]);
            btn.setTextColor(Color.WHITE);
            btn.setTextSize(11);
            btn.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(colors[i]));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 8, 0);
            btn.setLayoutParams(lp);
            final String label = labels[i].equals("ALL") ? "" : labels[i];
            btn.setOnClickListener(v -> {
                currentFilter = label;
                filterList(etSearch.getText().toString());
            });
            eventFilterContainer.addView(btn);
        }
    }

    private void loadAllRegistrations() {
        databaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                allRegistrations.clear();
                int total = 0;
                for (DataSnapshot eventSnap : snapshot.getChildren()) {
                    String eventType = eventSnap.getKey();
                    for (DataSnapshot reg : eventSnap.getChildren()) {
                        total++;
                        String name   = reg.child("name").getValue(String.class);
                        String branch = reg.child("branch").getValue(String.class);
                        String year   = reg.child("year").getValue(String.class);
                        String phone  = reg.child("phone").getValue(String.class);
                        String regId  = reg.child("registrationId").getValue(String.class);
                        String ts     = reg.child("timestamp").getValue(String.class);
                        String timeStr = "";
                        if (ts != null) {
                            try {
                                long millis = Long.parseLong(ts);
                                timeStr = new SimpleDateFormat("dd MMM yyyy, hh:mm a",
                                        Locale.getDefault()).format(new Date(millis));
                            } catch (Exception ignored) {}
                        }
                        allRegistrations.add(
                                "👤 " + name + "  |  " + branch +
                                        "\n📅 " + year + "   📞 " + phone +
                                        "\n🪪 " + regId + "   🕐 " + timeStr +
                                        "\n[" + eventType + "]");
                    }
                }
                tvTotalCount.setText("Total Registrations: " + total + " across all events");
                filterList(etSearch.getText().toString());
            }
            @Override public void onCancelled(DatabaseError e) {}
        });
    }

    private void filterList(String query) {
        filteredList.clear();
        String q = query.toLowerCase().trim();
        for (String entry : allRegistrations) {
            boolean ms = q.isEmpty() || entry.toLowerCase().contains(q);
            boolean mf = currentFilter.isEmpty() ||
                    entry.contains("[" + currentFilter + "]");
            if (ms && mf) filteredList.add(entry);
        }
        adapter.notifyDataSetChanged();
    }

    private void shareAsExcel() {
        if (filteredList.isEmpty()) {
            Toast.makeText(this,"No data to share",Toast.LENGTH_SHORT).show(); return;
        }
        StringBuilder sb = new StringBuilder("Name\tBranch\tYear\tPhone\tReg ID\tTime\tEvent\n");
        for (String entry : filteredList) {
            String clean = entry
                    .replaceAll("[👤📅📞🪪🕐\\[\\]]","")
                    .replace("|","\t").replace("\n","\t");
            sb.append(clean).append("\n");
        }
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "College Event Registrations");
        intent.putExtra(Intent.EXTRA_TEXT, sb.toString());
        startActivity(Intent.createChooser(intent, "Share / Export Data"));
    }

    private void showEventsTab() {
        eventsTab.setVisibility(View.VISIBLE);
        registrationsTab.setVisibility(View.GONE);
        btnTabEvents.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(0xFF8B0000));
        btnTabEvents.setTextColor(Color.WHITE);
        btnTabRegistrations.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(0xFFB71C1C));
        btnTabRegistrations.setTextColor(0xFFFFCDD2);
    }

    private void showRegistrationsTab() {
        eventsTab.setVisibility(View.GONE);
        registrationsTab.setVisibility(View.VISIBLE);
        btnTabRegistrations.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(0xFF8B0000));
        btnTabRegistrations.setTextColor(Color.WHITE);
        btnTabEvents.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(0xFFB71C1C));
        btnTabEvents.setTextColor(0xFFFFCDD2);
    }
}