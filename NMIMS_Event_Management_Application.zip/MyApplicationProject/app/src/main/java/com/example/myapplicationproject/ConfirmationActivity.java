package com.example.myapplicationproject;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

public class ConfirmationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        String regId     = getIntent().getStringExtra("registrationId");
        String name      = getIntent().getStringExtra("name");
        String eventName = getIntent().getStringExtra("eventName");
        String dateTime  = getIntent().getStringExtra("eventDateTime");
        String venue     = getIntent().getStringExtra("eventVenue");

        ((TextView) findViewById(R.id.tvRegId)).setText("🪪 Registration ID: " + regId);
        ((TextView) findViewById(R.id.tvConfirmName)).setText("👤 Name: " + name);
        ((TextView) findViewById(R.id.tvConfirmEvent)).setText("📋 Event: " + eventName);
        ((TextView) findViewById(R.id.tvConfirmDate)).setText("📅 Date: " + dateTime);
        ((TextView) findViewById(R.id.tvConfirmVenue)).setText("📍 Venue: " + venue);

        // Generate QR Code
        String qrContent = "Name: " + name +
                "\nEvent: " + eventName +
                "\nDate: " + dateTime +
                "\nVenue: " + venue +
                "\nID: " + regId;
        Bitmap qrBitmap = generateQRCode(qrContent);
        if (qrBitmap != null) {
            ((ImageView) findViewById(R.id.ivQRCode)).setImageBitmap(qrBitmap);
        }

        // WhatsApp share
        String shareText = "🎓 College Event Registration Confirmed!\n\n" +
                "👤 Name: " + name + "\n" +
                "📋 Event: " + eventName + "\n" +
                "📅 Date: " + dateTime + "\n" +
                "📍 Venue: " + venue + "\n" +
                "🪪 ID: " + regId + "\n\n" +
                "See you there! 🎉";

        findViewById(R.id.btnShareWhatsApp).setOnClickListener(v -> {
            Intent whatsapp = new Intent(Intent.ACTION_SEND);
            whatsapp.setType("text/plain");
            whatsapp.setPackage("com.whatsapp");
            whatsapp.putExtra(Intent.EXTRA_TEXT, shareText);
            try {
                startActivity(whatsapp);
            } catch (Exception e) {
                // WhatsApp not installed — use general share
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, shareText);
                startActivity(Intent.createChooser(share, "Share via"));
            }
        });

        findViewById(R.id.btnBackDashboard).setOnClickListener(v -> {
            Intent intent = new Intent(this, DashboardActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }

    private Bitmap generateQRCode(String content) {
        QRCodeWriter writer = new QRCodeWriter();
        try {
            BitMatrix matrix = writer.encode(content, BarcodeFormat.QR_CODE, 512, 512);
            int w = matrix.getWidth(), h = matrix.getHeight();
            Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565);
            for (int x = 0; x < w; x++)
                for (int y = 0; y < h; y++)
                    bmp.setPixel(x, y, matrix.get(x, y) ? Color.BLACK : Color.WHITE);
            return bmp;
        } catch (WriterException e) {
            return null;
        }
    }
}