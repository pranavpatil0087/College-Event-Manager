package com.example.myapplicationproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class EventDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);

        String eventType     = getIntent().getStringExtra("eventType");
        String eventName     = getIntent().getStringExtra("eventName");
        String dateTime      = getIntent().getStringExtra("eventDateTime");
        String venue         = getIntent().getStringExtra("eventVenue");
        String desc          = getIntent().getStringExtra("eventDesc");
        boolean venueConflict= getIntent().getBooleanExtra("venueConflict", false);

        ((TextView) findViewById(R.id.tvEventName)).setText(eventName);
        ((TextView) findViewById(R.id.tvDateTime)).setText(dateTime);
        ((TextView) findViewById(R.id.tvVenue)).setText(venue);
        ((TextView) findViewById(R.id.tvDesc)).setText(desc);

        TextView tvConflict = findViewById(R.id.tvVenueConflict);
        if (venueConflict) tvConflict.setVisibility(View.VISIBLE);

        Button btnReg = findViewById(R.id.btnRegisterEvent);
        btnReg.setOnClickListener(v -> {
            Intent intent = new Intent(this, RegistrationFormActivity.class);
            intent.putExtra("eventType",     eventType);
            intent.putExtra("eventName",     eventName);
            intent.putExtra("eventDateTime", dateTime);
            intent.putExtra("eventVenue",    venue);
            startActivity(intent);
        });
    }
}