package com.example.myapplicationproject;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;



import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;


public class CalendarActivity extends AppCompatActivity {

    TextView tvMonthYear, tvEventsList;
    GridView calendarGrid;
    Button btnPrev, btnNext;

    Calendar currentCal = Calendar.getInstance();

    // Events map: date string "2025-MM-DD" → event names
    Map<String, List<String>> eventMap = new HashMap<>();

    String[][] events = {
            {"2025-05-15", "🎤 Career Guidance Seminar"},
            {"2025-05-20", "🛠️ Android Dev Workshop"},
            {"2025-06-01", "🚀 Annual Technical Festival"},
            {"2025-06-10", "💻 24-Hour Hackathon"},
            {"2025-06-20", "🎭 Annual Cultural Fest"}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Build eventMap
        for (String[] e : events) {
            List<String> list = eventMap.getOrDefault(e[0], new ArrayList<>());
            list.add(e[1]);
            eventMap.put(e[0], list);
        }

        buildUI();
        renderCalendar();
    }

    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setBackgroundColor(Color.parseColor("#C62828"));
        header.setPadding(24, 40, 24, 24);
        header.setOrientation(LinearLayout.VERTICAL);

        TextView title = new TextView(this);
        title.setText("📅 Event Calendar");
        title.setTextSize(22);
        title.setTextColor(Color.WHITE);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(title);
        root.addView(header);

        // Month navigation
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(android.view.Gravity.CENTER_VERTICAL);
        nav.setPadding(16, 16, 16, 8);
        nav.setBackgroundColor(Color.parseColor("#FFEBEE"));

        btnPrev = new Button(this);
        btnPrev.setText("◀");
        btnPrev.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(Color.parseColor("#C62828")));
        btnPrev.setTextColor(Color.WHITE);

        tvMonthYear = new TextView(this);
        tvMonthYear.setTextSize(18);
        tvMonthYear.setTextColor(Color.parseColor("#C62828"));
        tvMonthYear.setTypeface(null, android.graphics.Typeface.BOLD);
        tvMonthYear.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        tvMonthYear.setLayoutParams(mp);

        btnNext = new Button(this);
        btnNext.setText("▶");
        btnNext.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(Color.parseColor("#C62828")));
        btnNext.setTextColor(Color.WHITE);

        nav.addView(btnPrev);
        nav.addView(tvMonthYear);
        nav.addView(btnNext);
        root.addView(nav);

        // Day headers
        LinearLayout days = new LinearLayout(this);
        days.setOrientation(LinearLayout.HORIZONTAL);
        days.setBackgroundColor(Color.parseColor("#B71C1C"));
        String[] dayNames = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
        for (String d : dayNames) {
            TextView tv = new TextView(this);
            tv.setText(d);
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(12);
            tv.setGravity(android.view.Gravity.CENTER);
            tv.setPadding(4, 8, 4, 8);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
            tv.setLayoutParams(lp);
            days.addView(tv);
        }
        root.addView(days);

        // Grid
        calendarGrid = new GridView(this);
        calendarGrid.setNumColumns(7);
        calendarGrid.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
        calendarGrid.setLayoutParams(glp);
        root.addView(calendarGrid);

        // Events list for selected month
        TextView eventsHeader = new TextView(this);
        eventsHeader.setText("Events This Month:");
        eventsHeader.setTextSize(15);
        eventsHeader.setTextColor(Color.parseColor("#C62828"));
        eventsHeader.setTypeface(null, android.graphics.Typeface.BOLD);
        eventsHeader.setPadding(16, 12, 16, 4);
        root.addView(eventsHeader);

        tvEventsList = new TextView(this);
        tvEventsList.setTextSize(14);
        tvEventsList.setTextColor(Color.parseColor("#333333"));
        tvEventsList.setPadding(16, 4, 16, 16);
        root.addView(tvEventsList);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        btnPrev.setOnClickListener(v -> {
            currentCal.add(Calendar.MONTH, -1);
            renderCalendar();
        });
        btnNext.setOnClickListener(v -> {
            currentCal.add(Calendar.MONTH, 1);
            renderCalendar();
        });
    }

    private void renderCalendar() {
        // Month year label
        String[] months = {"January","February","March","April","May","June",
                "July","August","September","October","November","December"};
        int month = currentCal.get(Calendar.MONTH);
        int year  = currentCal.get(Calendar.YEAR);
        tvMonthYear.setText(months[month] + " " + year);

        // Build grid data
        Calendar cal = (Calendar) currentCal.clone();
        cal.set(Calendar.DAY_OF_MONTH, 1);
        int startDay = cal.get(Calendar.DAY_OF_WEEK) - 1;
        int maxDay   = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

        List<String> cells = new ArrayList<>();
        for (int i = 0; i < startDay; i++) cells.add("");
        for (int d = 1; d <= maxDay; d++) cells.add(String.valueOf(d));
        while (cells.size() % 7 != 0) cells.add("");

        String monthStr = String.format(Locale.getDefault(), "%04d-%02d", year, month + 1);

        // Adapter
        ArrayAdapter<String> gridAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, cells) {
            @Override
            public View getView(int pos, View convertView, ViewGroup parent) {
                TextView tv = new TextView(getContext());
                String cell = cells.get(pos);
                tv.setText(cell);
                tv.setGravity(android.view.Gravity.CENTER);
                tv.setPadding(4, 12, 4, 12);
                tv.setTextSize(14);

                if (!cell.isEmpty()) {
                    String dateKey = String.format(Locale.getDefault(),
                            "%04d-%02d-%02d", year, month + 1, Integer.parseInt(cell));
                    if (eventMap.containsKey(dateKey)) {
                        tv.setBackgroundColor(Color.parseColor("#C62828"));
                        tv.setTextColor(Color.WHITE);
                        tv.setTypeface(null, android.graphics.Typeface.BOLD);
                    } else {
                        tv.setTextColor(Color.parseColor("#333333"));
                    }
                    // Today highlight
                    Calendar today = Calendar.getInstance();
                    if (today.get(Calendar.YEAR) == year &&
                            today.get(Calendar.MONTH) == month &&
                            today.get(Calendar.DAY_OF_MONTH) == Integer.parseInt(cell)) {
                        tv.setBackgroundColor(Color.parseColor("#FFCDD2"));
                        tv.setTextColor(Color.parseColor("#C62828"));
                        tv.setTypeface(null, android.graphics.Typeface.BOLD);
                    }
                }
                return tv;
            }
        };
        calendarGrid.setAdapter(gridAdapter);

        // Show events list for this month
        StringBuilder sb = new StringBuilder();
        for (String[] e : events) {
            if (e[0].startsWith(monthStr)) {
                sb.append("• ").append(e[0]).append("  →  ").append(e[1]).append("\n");
            }
        }
        tvEventsList.setText(sb.length() > 0 ? sb.toString() : "No events this month.");
    }
}