package com.example.myapplicationproject;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.*;
import java.util.HashMap;
import java.util.Map;

public class RegistrationFormActivity extends AppCompatActivity {

    EditText etName, etBranch, etYear, etPhone;
    Button btnSubmit;
    DatabaseReference databaseRef;
    String selectedBranch = "", selectedYear = "";

    final String[] branches = {
            "IT - Information Technology",
            "AI ML - Artificial Intelligence & ML",
            "CE - Computer Engineering",
            "CS - Computer Science"
    };
    final String[] years = {"1st Year","2nd Year","3rd Year","4th Year"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_form);

        databaseRef = FirebaseDatabase.getInstance().getReference("registrations");
        etName    = findViewById(R.id.etName);
        etBranch  = findViewById(R.id.etBranch);
        etYear    = findViewById(R.id.etYear);
        etPhone   = findViewById(R.id.etPhone);
        btnSubmit = findViewById(R.id.btnSubmit);

        String eventType     = getIntent().getStringExtra("eventType");
        String eventName     = getIntent().getStringExtra("eventName");
        String eventDateTime = getIntent().getStringExtra("eventDateTime");
        String eventVenue    = getIntent().getStringExtra("eventVenue");

        etBranch.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Select Branch")
                .setItems(branches, (d, w) -> { selectedBranch = branches[w]; etBranch.setText(selectedBranch); })
                .show());

        etYear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Select Year")
                .setItems(years, (d, w) -> { selectedYear = years[w]; etYear.setText(selectedYear); })
                .show());

        btnSubmit.setOnClickListener(v ->
                submitRegistration(eventType, eventName, eventDateTime, eventVenue));
    }

    private void submitRegistration(String eventType, String eventName,
                                    String eventDateTime, String eventVenue) {
        String name   = etName.getText().toString().trim();
        String branch = etBranch.getText().toString().trim();
        String year   = etYear.getText().toString().trim();
        String phone  = etPhone.getText().toString().trim();

        if (name.isEmpty())  { Toast.makeText(this,"Enter name!",Toast.LENGTH_SHORT).show(); return; }
        if (branch.isEmpty()){ Toast.makeText(this,"Select branch!",Toast.LENGTH_SHORT).show(); return; }
        if (year.isEmpty())  { Toast.makeText(this,"Select year!",Toast.LENGTH_SHORT).show(); return; }
        if (phone.length()!=10){ Toast.makeText(this,"Enter valid 10-digit phone!",Toast.LENGTH_SHORT).show(); return; }

        // Check duplicate
        databaseRef.child(eventType).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot reg : snapshot.getChildren()) {
                    String existingPhone = reg.child("phone").getValue(String.class);
                    if (phone.equals(existingPhone)) {
                        Toast.makeText(RegistrationFormActivity.this,
                                "⚠️ You already registered for this event!",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                saveRegistration(eventType, eventName, eventDateTime, eventVenue,
                        name, branch, year, phone);
            }
            @Override public void onCancelled(DatabaseError e) {}
        });
    }

    private void saveRegistration(String eventType, String eventName,
                                  String eventDateTime, String eventVenue,
                                  String name, String branch, String year, String phone) {
        btnSubmit.setEnabled(false);
        btnSubmit.setText("Submitting...");

        String regId      = databaseRef.push().getKey();
        String regIdShort = "EVT" + System.currentTimeMillis() % 100000;

        Map<String, String> data = new HashMap<>();
        data.put("registrationId", regIdShort);
        data.put("name",           name);
        data.put("branch",         branch);
        data.put("year",           year);
        data.put("phone",          phone);
        data.put("eventType",      eventType);
        data.put("eventName",      eventName);
        data.put("eventDateTime",  eventDateTime);
        data.put("eventVenue",     eventVenue);
        data.put("timestamp",      String.valueOf(System.currentTimeMillis()));

        databaseRef.child(eventType).child(regId).setValue(data)
                .addOnSuccessListener(unused -> {
                    Intent intent = new Intent(this, ConfirmationActivity.class);
                    intent.putExtra("registrationId", regIdShort);
                    intent.putExtra("name",           name);
                    intent.putExtra("eventName",      eventName);
                    intent.putExtra("eventDateTime",  eventDateTime);
                    intent.putExtra("eventVenue",     eventVenue);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    btnSubmit.setEnabled(true);
                    btnSubmit.setText("SUBMIT REGISTRATION");
                    Toast.makeText(this, "Failed: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                });
    }
}